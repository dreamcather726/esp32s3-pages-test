// 实物：3V3 → FSR402 → GPIO34 → 10kΩ → GND。
// Wokwi：电位器 SIG 接 GPIO34，代替变化的模拟输入。
const int FSR_PIN = 34;

void setup() {
  Serial.begin(115200);
  pinMode(FSR_PIN, INPUT);
  Serial.println("FSR402压力传感器测试开始");
}

void loop() {
  int rawValue = analogRead(FSR_PIN);
  float voltage = rawValue * (3.3 / 4095.0);
  Serial.printf("ADC值: %d | 电压: %.2fV | 压力: ", rawValue, voltage);
  if (rawValue < 100) Serial.println("无压力");
  else if (rawValue < 500) Serial.println("轻压");
  else if (rawValue < 800) Serial.println("中压");
  else Serial.println("重压");
  delay(200);
}
