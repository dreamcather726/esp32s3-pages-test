const int TRIG_PIN = 26;
const int ECHO_PIN = 27;

void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  digitalWrite(TRIG_PIN, LOW);
  Serial.println("HC-SR04超声波传感器测试");
}

void loop() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) {
    Serial.println("HC-SR04 无回波");
  } else {
    long distance = duration * 0.034 / 2;
    Serial.printf("距离: %ld cm", distance);
    if (distance < 5) Serial.println(" - 非常近!");
    else if (distance < 20) Serial.println(" - 近距离");
    else if (distance < 100) Serial.println(" - 中距离");
    else if (distance < 400) Serial.println(" - 远距离");
    else Serial.println(" - 超出测量范围");
  }
  delay(500);
}
