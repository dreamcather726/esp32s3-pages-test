#include <HX711.h>

HX711 scale;
const int DT_PIN = 32;
const int SCK_PIN = 33;
// 教程的 2280 是示例系数；Wokwi 5kg 模型使用 420 原始值/kg。
// 使用实物时需要按已知砝码重新标定。
const float CALIBRATION_FACTOR = 420.0;

void setup() {
  Serial.begin(115200);
  scale.begin(DT_PIN, SCK_PIN);
  scale.set_scale(CALIBRATION_FACTOR);
  if (scale.wait_ready_timeout(2000)) {
    scale.tare();  // 开始时保持空载
    Serial.println("HX711 去皮完成");
  } else {
    Serial.println("HX711 未就绪，请检查接线");
  }
}

void loop() {
  if (scale.is_ready()) {
    float weight = scale.get_units(5);
    Serial.printf("重量: %.2f kg\n", weight);
  } else {
    Serial.println("HX711 未就绪，请检查接线");
  }
  delay(500);
}
