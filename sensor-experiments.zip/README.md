﻿# 传感器基础实验

双击 `index.html` 打开页面。选择四个独立实验之一、“综合采集”或“MQTT 舵机控制”。基础实验点击开始后调整输入，观察读数和串口。停止保留结果；继续运行保留去皮基准；重置和切换实验清空结果并重新初始化。

网页用输入参数演示实验现象，不执行 Arduino 代码。各文件夹包含可用于 ESP32 / Wokwi 的 `sketch.ino`、`diagram.json`、`libraries.txt`；在 Wokwi 新建 ESP32 项目并使用对应文件。

界面沿用原时钟工作台布局，使用黑、白、灰色调：左侧代码和串口，右侧ESP32与传感器接线画布、输入栏，底部状态卡片。电源、地、信号线以不同线型区分。页面顶部可修改网页名称，点击“保存名称”同步修改页头和浏览器标签，并保存在当前浏览器；这是个人名称设置，不会改动其他访客的默认名称或网页 URL。所有访客的默认名称可在 shell.html 与 mqtt-app.mjs 中修改。

## MQTT 控制

选择“MQTT 舵机控制”，点击“连接 MQTT”。默认服务器为 `wss://broker.hivemq.com:8884/mqtt`，网页使用真实 MQTT over WebSocket 消息，不需要登录。MQTT.js 5.16.0 已内嵌，离线打开也能查看基础实验，联网后才能连接 MQTT。

- 网页实验设备：点击“开始实验”，网页作为实验设备接收控制命令，模拟舵机转动与传感器输入，每2秒发布 JSON。暂停时停止读取和发布，确认消息仍能发送。
- 控制 ESP32：网页仅发送命令并显示设备上传的数据，不发布网页模拟读数。将 mqtt/sketch.ino 中 TOPIC_PREFIX 改为网页显示的主题前缀，使用配套接线图在 Wokwi 运行；实物还需设置 WiFi 并重新标定 HX711。ESP32 用 broker.hivemq.com:1883 连接同一服务，网页用加密 WebSocket 8884 端口。
- 用 MQTTX 控制网页：MQTTX 连接相同服务器，将下表中的 `<前缀>` 换成页面显示的值。每次默认生成独立前缀并在连接时保存，也可改成 smartfarm 以匹配参考文档。避免多个实验设备使用同一前缀；可以有多个控制端。

| 主题 | 消息内容 | 实验现象 |
| --- | --- | --- |
| `<前缀>/servo` | 0–180 的整数，如 135 | 舵机转到指定角度；返回 Servo set to 135 |
| `<前缀>/control` | stop / start / toggle | 暂停、恢复或切换采集状态 |
| `<前缀>/control` | mode 0 / mode 1 / mode 2 | 全部传感器、只显示MPU6050、只显示压力和重量的串口输出 |
| `<前缀>/data` | JSON | 六轴运动、压力原始值、重量、距离、角度、采集状态和模式 |

网页拒绝无效角度、模式以及格式不完整的设备数据；网页实验设备不执行 retained 控制消息，避免旧命令在连接时生效。当前连接断开后显示提示，可再次连接。切换实验会断开 MQTT。公共服务器只用于实验数据；可在服务器输入框换成自己的 wss:// 地址。

已验证两路真实 MQTT TLS WebSocket 客户端的控制与数据回传；ESP32 示例使用 ESP32 Arduino 3.2.0 编译通过。基础模型测试覆盖分级边界、去皮及超声波超时。浏览器预览和 GitHub 自动上传受当前工具的访问限制，不能据此认为已上线。

| 实验 | 对应现象 | 引脚 |
| --- | --- | --- |
| MPU6050 | 三轴加速度与角速度 | SDA21、SCL22、3V3、GND |
| FSR402 | ADC、电压、无压力/轻压/中压/重压；200ms更新 | 电位器SIG34、3V3、GND |
| HX711 | 启动去皮、放上或移除负载后的相对重量 | DT32、SCK33、Wokwi 5V、GND |
| HC-SR04 | 整数距离、远近提示、无回波 | TRIG26、ECHO27、5V、GND |
| 综合采集 | 同一轮输出四种传感器数据；500ms更新 | 以上全部引脚同时接线，共地 |
| MQTT 舵机控制 | 真实命令收发、0–180°角度、暂停/恢复、显示模式 | 四种传感器 + 舵机PWM13、5V、GND |

## 参考内容与适配

- [FSR402](https://wcn5nr4htkrb.feishu.cn/wiki/RgtLwa8ZpiRUs8keX8dc5NnBnfc)：电位器替代FSR，ADC为0–4095，电压按ADC×3.3/4095换算；分级边界为100、500、800。保留200ms采样间隔。实物压力分级需调整阈值，不能直接测量牛顿数。
- [HC-SR04](https://wcn5nr4htkrb.feishu.cn/wiki/GmPlwxo1wij48KkD7TccVQhhnNb)：GPIO26/27，10µs触发，距离按回波微秒数×0.034/2取整数；提示边界为5、20、100、400cm。加入30ms超时，避免无回波时持续等待。
- [ESP32接多种传感器](https://wcn5nr4htkrb.feishu.cn/wiki/OW9fwyuZliZkxBkVasNcvsFhneG)：四种数据持续输出，HX711去皮和get_units(5)，GPIO32/33；综合距离提示按10、50、200cm分档。
- [用MQTT舵机控制传感器](https://wcn5nr4htkrb.feishu.cn/wiki/Ps12whZ9iiQ6OikyvRAckM5inXb)：新增 MQTT 控制实验，保留参考的角度、停止/启动/切换与 mode 0–2 命令和两秒发布间隔；按用户要求保持简单的工作台界面。
- [HiveMQ 公共服务器](https://www.mqtt-dashboard.com/)：浏览器连接使用TLS WebSocket 8884端口。
- [MQTT.js](https://github.com/mqttjs/MQTT.js)：浏览器客户端内嵌5.16.0，MIT许可证见 vendor/MQTT-LICENSE.md。

HX711教程系数2280是示例标定值。项目使用 [Wokwi 5kg模型](https://docs.wokwi.com/parts/wokwi-hx711)，0–5kg对应原始值0–2100，因此采用420原始值/kg；实物需用已知砝码重新标定。开始时默认空载；如果带负载启动，它会被当作去皮基准。负载低于基准时相对重量可以为负。

超声波网页用340m/s理想回波时间，Wokwi内部时序可能产生少量距离差异。网页允许示意输入到450cm以展示“超出测量范围”；Wokwi滑块的范围是2–400cm。实物ECHO为5V，需分压：ECHO→1kΩ→GPIO27→2kΩ→GND。HX711实物的数字逻辑需与ESP32的3.3V兼容。

FSR实物接线：3V3→FSR402→GPIO34→10kΩ→GND。仿真中按教程使用电位器输入，不假定实际按压力与ADC之间的固定关系。MPU6050保留用户提供的±2g、±2000°/s量程和原始值换算。

## 维护

修改 `shell.html`、`app.mjs`、`model.mjs` 或五份源码，然后运行 `python scripts/package_experiments.py`。它同步生成本目录页面、`public/index.html`、`pages-test/index.html`、`clock-lab/clock.html`、Wokwi文件及两个压缩包。

本地预览：`python scripts/preview_clock.py`，打开 http://127.0.0.1:8766/clock.html。旧命令 `python scripts/package_clock.py` 也生成当前页面。
