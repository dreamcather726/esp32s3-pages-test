﻿# 传感器基础实验

双击 `index.html` 打开离线页面。选择四个独立实验之一，或选择“综合采集”，点击开始后调整输入，观察读数和串口。停止保留结果；继续运行保留去皮基准；重置和切换实验清空结果并重新初始化。

网页用输入参数演示实验现象，不执行 Arduino 代码。各文件夹包含可用于 ESP32 / Wokwi 的 `sketch.ino`、`diagram.json`、`libraries.txt`；在 Wokwi 新建 ESP32 项目并使用对应文件。

界面沿用原三舵机时钟工作台的布局与配色：左侧代码和串口，右侧ESP32与传感器接线画布、输入栏，底部传感器状态卡片。实验保持固定接线，切换实验后自动更新代码、接线和状态；综合采集的四张状态卡片对应四种传感器，完整数据在串口中输出。

| 实验 | 对应现象 | 引脚 |
| --- | --- | --- |
| MPU6050 | 三轴加速度与角速度 | SDA21、SCL22、3V3、GND |
| FSR402 | ADC、电压、无压力/轻压/中压/重压；200ms更新 | 电位器SIG34、3V3、GND |
| HX711 | 启动去皮、放上或移除负载后的相对重量 | DT32、SCK33、Wokwi 5V、GND |
| HC-SR04 | 整数距离、远近提示、无回波 | TRIG26、ECHO27、5V、GND |
| 综合采集 | 同一轮输出四种传感器数据；500ms更新 | 以上全部引脚同时接线，共地 |

## 参考内容与适配

- [FSR402](https://wcn5nr4htkrb.feishu.cn/wiki/RgtLwa8ZpiRUs8keX8dc5NnBnfc)：电位器替代FSR，ADC为0–4095，电压按ADC×3.3/4095换算；分级边界为100、500、800。保留200ms采样间隔。实物压力分级需调整阈值，不能直接测量牛顿数。
- [HC-SR04](https://wcn5nr4htkrb.feishu.cn/wiki/GmPlwxo1wij48KkD7TccVQhhnNb)：GPIO26/27，10µs触发，距离按回波微秒数×0.034/2取整数；提示边界为5、20、100、400cm。加入30ms超时，避免无回波时持续等待。
- [ESP32接多种传感器](https://wcn5nr4htkrb.feishu.cn/wiki/OW9fwyuZliZkxBkVasNcvsFhneG)：四种数据持续输出，HX711去皮和get_units(5)，GPIO32/33；综合距离提示按10、50、200cm分档。
- [用MQTT舵机控制传感器](https://wcn5nr4htkrb.feishu.cn/wiki/Ps12whZ9iiQ6OikyvRAckM5inXb)：参考传感器采集函数和引脚。按本次任务的简化要求，项目聚焦数据获取与实验现象。

HX711教程系数2280是示例标定值。项目使用 [Wokwi 5kg模型](https://docs.wokwi.com/parts/wokwi-hx711)，0–5kg对应原始值0–2100，因此采用420原始值/kg；实物需用已知砝码重新标定。开始时默认空载；如果带负载启动，它会被当作去皮基准。负载低于基准时相对重量可以为负。

超声波网页用340m/s理想回波时间，Wokwi内部时序可能产生少量距离差异。网页允许示意输入到450cm以展示“超出测量范围”；Wokwi滑块的范围是2–400cm。实物ECHO为5V，需分压：ECHO→1kΩ→GPIO27→2kΩ→GND。HX711实物的数字逻辑需与ESP32的3.3V兼容。

FSR实物接线：3V3→FSR402→GPIO34→10kΩ→GND。仿真中按教程使用电位器输入，不假定实际按压力与ADC之间的固定关系。MPU6050保留用户提供的±2g、±2000°/s量程和原始值换算。

## 维护

修改 `shell.html`、`app.mjs`、`model.mjs` 或五份源码，然后运行 `python scripts/package_experiments.py`。它同步生成本目录页面、`public/index.html`、`pages-test/index.html`、`clock-lab/clock.html`、Wokwi文件及两个压缩包。

本地预览：`python scripts/preview_clock.py`，打开 http://127.0.0.1:8766/clock.html。旧命令 `python scripts/package_clock.py` 也生成当前页面。
