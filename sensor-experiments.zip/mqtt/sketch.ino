// MQTT + 舵机 + 四种传感器。浏览器选择“控制 ESP32”，并使用相同主题前缀。
#include <Wire.h>
#include <MPU6050.h>
#include <HX711.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <ESP32Servo.h>

const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";
const char* MQTT_HOST = "broker.hivemq.com";
// 将这里改成网页上显示的主题前缀，如 esp32lab/abcd1234。
const char* TOPIC_PREFIX = "esp32lab/demo";
const int FSR_PIN = 34, TRIG_PIN = 26, ECHO_PIN = 27;
const int DT_PIN = 32, SCK_PIN = 33, SERVO_PIN = 13;
MPU6050 mpu;
HX711 scale;
Servo servo;
WiFiClient network;
PubSubClient client(network);
String controlTopic, servoTopic, dataTopic;
bool systemStopped = false;
int servoAngle = 90, currentMode = 0;
float accel[3] = {0,0,1}, gyro[3] = {0,0,0}, weight = 0;
int fsrValue = 0;
long distanceCm = -1;
unsigned long lastSample = 0, lastPublish = 0, lastConnect = 0;

bool integerInRange(const String& text, int maximum, int& value) {
  if (text.length() == 0 || text.length() > 3) return false;
  for (unsigned int i = 0; i < text.length(); i++)
    if (text[i] < '0' || text[i] > '9') return false;
  value = text.toInt();
  return value <= maximum;
}
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String text;
  for (unsigned int i = 0; i < length; i++) text += (char)payload[i];
  text.trim();
  Serial.printf("收到 %s：%s\n", topic, text.c_str());
  int value;
  String ack;
  if (String(topic) == servoTopic) {
    if (!integerInRange(text,180,value)) { Serial.println("角度需为 0–180 的整数"); return; }
    servoAngle = value; servo.write(servoAngle);
    ack = "Servo set to " + String(servoAngle);
  } else if (String(topic) == controlTopic) {
    if (text == "stop") systemStopped = true;
    else if (text == "start") systemStopped = false;
    else if (text == "toggle") systemStopped = !systemStopped;
    else if (text.startsWith("mode ")) {
      if (!integerInRange(text.substring(5),2,value)) return;
      currentMode = value; ack = "Mode changed to " + String(currentMode);
    } else return; // 忽略确认消息，避免消息循环。
    if (ack.length() == 0) ack = systemStopped ? "System stopped" : "System started";
  }
  if (ack.length()) {client.publish(controlTopic.c_str(),ack.c_str()); Serial.println(ack);}
}
void readSensors() {
  int16_t ax,ay,az,gx,gy,gz;
  mpu.getMotion6(&ax,&ay,&az,&gx,&gy,&gz);
  accel[0]=ax/16384.0; accel[1]=ay/16384.0; accel[2]=az/16384.0;
  gyro[0]=gx/16.4; gyro[1]=gy/16.4; gyro[2]=gz/16.4;
  fsrValue = analogRead(FSR_PIN);
  if (scale.is_ready()) weight = scale.get_units(5);
  digitalWrite(TRIG_PIN,LOW); delayMicroseconds(2);
  digitalWrite(TRIG_PIN,HIGH); delayMicroseconds(10); digitalWrite(TRIG_PIN,LOW);
  unsigned long duration = pulseIn(ECHO_PIN,HIGH,30000);
  distanceCm = duration ? duration * 0.034 / 2 : -1;
  if (currentMode != 2)
    Serial.printf("加速度 %.2f %.2f %.2f g | 角速度 %.2f %.2f %.2f °/s\n",accel[0],accel[1],accel[2],gyro[0],gyro[1],gyro[2]);
  if (currentMode != 1) {
    const char* pressure = fsrValue < 100 ? "无压力" : fsrValue < 500 ? "轻压" : fsrValue < 800 ? "中压" : "重压";
    Serial.printf("FSR ADC %d | %.2f V | %s | 重量 %.2f kg\n",fsrValue,fsrValue*3.3/4095.0,pressure,weight);
  }
  if (currentMode == 0) {
    if (distanceCm < 0) Serial.println("HC-SR04 无回波");
    else Serial.printf("距离 %ld cm\n",distanceCm);
  }
}
void publishData() {
  String distance = distanceCm < 0 ? "null" : String(distanceCm);
  char payload[512];
  snprintf(payload,sizeof(payload),
    "{\"accelX\":%.2f,\"accelY\":%.2f,\"accelZ\":%.2f,\"gyroX\":%.2f,\"gyroY\":%.2f,\"gyroZ\":%.2f,\"fsrValue\":%d,\"weight\":%.2f,\"distance\":%s,\"systemStopped\":%s,\"currentMode\":%d,\"servoAngle\":%d}",
    accel[0],accel[1],accel[2],gyro[0],gyro[1],gyro[2],fsrValue,weight,distance.c_str(),systemStopped?"true":"false",currentMode,servoAngle);
  if (client.publish(dataTopic.c_str(),payload)) Serial.println("MQTT 数据已发送");
}
void setup() {
  Serial.begin(115200);
  controlTopic = String(TOPIC_PREFIX)+"/control";
  servoTopic = String(TOPIC_PREFIX)+"/servo";
  dataTopic = String(TOPIC_PREFIX)+"/data";
  Wire.begin(21,22); mpu.initialize();
  if (!mpu.testConnection()) {Serial.println("MPU6050 连接失败"); while(true) delay(1000);}
  mpu.setFullScaleGyroRange(MPU6050_GYRO_FS_2000);
  mpu.setFullScaleAccelRange(MPU6050_ACCEL_FS_2);
  scale.begin(DT_PIN,SCK_PIN);
  scale.set_scale(420.0); // Wokwi 5 kg 模型；实物请重新标定。
  if (scale.wait_ready_timeout(2000)) scale.tare();
  pinMode(FSR_PIN,INPUT); pinMode(TRIG_PIN,OUTPUT); pinMode(ECHO_PIN,INPUT);
  servo.setPeriodHertz(50); servo.attach(SERVO_PIN,500,2400); servo.write(servoAngle);
  WiFi.begin(WIFI_SSID,WIFI_PASSWORD);
  client.setServer(MQTT_HOST,1883); client.setCallback(mqttCallback);
  client.setBufferSize(768); client.setSocketTimeout(2);
  Serial.printf("主题前缀：%s\n",TOPIC_PREFIX);
}
void loop() {
  unsigned long now = millis();
  if (WiFi.status() == WL_CONNECTED && !client.connected() && (lastConnect == 0 || now-lastConnect >= 5000)) {
    lastConnect = now;
    String id = "esp32lab-"+WiFi.macAddress();
    if (client.connect(id.c_str())) {
      client.subscribe(controlTopic.c_str()); client.subscribe(servoTopic.c_str());
      Serial.println("MQTT 已连接");
    }
  }
  client.loop();
  if (!systemStopped && now-lastSample >= 500) {lastSample = now; readSensors();}
  // 暂停时上传最后一次读数及暂停状态，便于控制端确认状态。
  if (client.connected() && now-lastPublish >= 2000) {lastPublish=now; publishData();}
  delay(5);
}
