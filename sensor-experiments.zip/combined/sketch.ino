// 参考飞书多传感器实验，仅保留四种传感器的数据采集。
#include <Wire.h>
#include <MPU6050.h>
#include <HX711.h>

MPU6050 mpu;
HX711 scale;
const int FSR_PIN = 34;
const int TRIG_PIN = 26;
const int ECHO_PIN = 27;
const int DT_PIN = 32;
const int SCK_PIN = 33;
// Wokwi 5kg 称重模型为 420 原始值/kg。实物需自行标定。
const float CALIBRATION_FACTOR = 420.0;

void setup() {
  Serial.begin(115200);
  Wire.begin();
  mpu.initialize();
  if (!mpu.testConnection()) {
    Serial.println("MPU6050 连接失败，请检查接线");
    while (1) { delay(1000); }
  }
  mpu.setFullScaleGyroRange(MPU6050_GYRO_FS_2000);
  mpu.setFullScaleAccelRange(MPU6050_ACCEL_FS_2);
  pinMode(FSR_PIN, INPUT);
  scale.begin(DT_PIN, SCK_PIN);
  scale.set_scale(CALIBRATION_FACTOR);
  if (scale.wait_ready_timeout(2000)) {
    scale.tare();  // 开始时保持空载
    Serial.println("HX711 去皮完成");
  } else {
    Serial.println("HX711 未就绪，请检查接线");
  }
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  digitalWrite(TRIG_PIN, LOW);
  Serial.println("所有传感器初始化完成");
}

void loop() {
  int16_t ax, ay, az, gx, gy, gz;
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
  Serial.printf("加速度 X:%.2fg Y:%.2fg Z:%.2fg | ", ax/16384.0, ay/16384.0, az/16384.0);
  Serial.printf("陀螺仪 X:%.2f°/s Y:%.2f°/s Z:%.2f°/s\n", gx/16.4, gy/16.4, gz/16.4);

  int rawValue = analogRead(FSR_PIN);
  float voltage = rawValue * (3.3 / 4095.0);
  Serial.printf("FSR ADC值: %d | 电压: %.2fV | 压力: ", rawValue, voltage);
  if (rawValue < 100) Serial.println("无压力");
  else if (rawValue < 500) Serial.println("轻压");
  else if (rawValue < 800) Serial.println("中压");
  else Serial.println("重压");

  if (scale.is_ready()) {
    Serial.printf("重量: %.2f kg\n", scale.get_units(5));
  } else {
    Serial.println("HX711 未就绪，请检查接线");
  }

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) {
    Serial.println("HC-SR04 无回波");
  } else {
    long distance = duration * 0.034 / 2;
    Serial.printf("距离: %ld cm", distance);
    if (distance < 10) Serial.println(" - 很近!");
    else if (distance < 50) Serial.println(" - 近距离");
    else if (distance < 200) Serial.println(" - 中距离");
    else Serial.println(" - 远距离");
  }
  Serial.println("----------");
  delay(500);
}
