#include <Wire.h>
#include <MPU6050.h>

MPU6050 mpu;

void setup() {
  Serial.begin(115200);
  Wire.begin();  // ESP32: SDA=21, SCL=22
  Serial.println("初始化MPU6050...");
  mpu.initialize();
  if (mpu.testConnection()) {
    Serial.println("MPU6050 连接成功");
  } else {
    Serial.println("MPU6050 连接失败，请检查接线或I2C地址!");
    while (1) { delay(1000); }
  }
  mpu.setFullScaleGyroRange(MPU6050_GYRO_FS_2000);
  mpu.setFullScaleAccelRange(MPU6050_ACCEL_FS_2);
  Serial.println("MPU6050 初始化成功");
}

void loop() {
  int16_t ax, ay, az;
  int16_t gx, gy, gz;
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
  float accelX = ax / 16384.0;
  float accelY = ay / 16384.0;
  float accelZ = az / 16384.0;
  float gyroX = gx / 16.4;
  float gyroY = gy / 16.4;
  float gyroZ = gz / 16.4;
  Serial.printf("加速度 X:%.2f Y:%.2f Z:%.2f g\n", accelX, accelY, accelZ);
  Serial.printf("陀螺仪 X:%.2f Y:%.2f Z:%.2f °/s\n", gyroX, gyroY, gyroZ);
  Serial.println("---");
  delay(500);
}
